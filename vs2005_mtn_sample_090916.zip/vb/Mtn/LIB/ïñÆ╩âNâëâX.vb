﻿Imports System.IO
Imports System.Text
Imports System.Runtime.InteropServices

Public Class INI


    Public ini As String

    ' ******************************************************
    ' ini ファイル読み込み
    ' ******************************************************
    <DllImport("Kernel32.dll", CharSet:=CharSet.Auto)> _
    Private Shared Function GetPrivateProfileString( _
                ByVal lpAppName As String, _
                ByVal lpKeyName As String, _
                ByVal lpDefault As String, _
                ByVal lpReturnedString As StringBuilder, _
                ByVal nSize As Integer, _
                ByVal lpFileName As String) As Integer
    End Function

    ' ********************************************************
    ' (コンストラクタの定義)( Sub で定義する )
    ' ********************************************************
    Public Sub New(ByVal path As String)

        ini = path

    End Sub

    ' ******************************************************
    ' 接続 DB の種類を取得
    ' ******************************************************
    Public Function GetDBType() As Integer

        Dim str As StringBuilder = New StringBuilder(512)

        Call GetPrivateProfileString("MTN", "ConnetctType", "1", str, 512, ini)
        GetDBType = Integer.Parse(str.ToString())

    End Function

    ' ******************************************************
    ' 接続 Server を取得
    ' ******************************************************
    Public Function GetServer() As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType()

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "Server", "localhost", str, 512, ini)
            Case 2
                Call GetPrivateProfileString("Oracle", "Server", "localhost/ORCL", str, 512, ini)

        End Select

        GetServer = str.ToString()

    End Function

    ' ******************************************************
    ' 接続 Server を取得
    ' ******************************************************
    Public Function GetDB() As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType()

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "Database", "", str, 512, ini)
            Case 2
                str.Append("")

        End Select

        GetDB = str.ToString()

    End Function

    ' ******************************************************
    ' 接続 Server を取得
    ' ******************************************************
    Public Function GetUser() As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType()

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "User", "", str, 512, ini)
            Case 2
                Call GetPrivateProfileString("Oracle", "User", "", str, 512, ini)

        End Select

        GetUser = str.ToString()

    End Function

    ' ******************************************************
    ' 接続 Server を取得
    ' ******************************************************
    Public Function GetPass() As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType()

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "Password", "", str, 512, ini)
            Case 2
                Call GetPrivateProfileString("Oracle", "Password", "", str, 512, ini)

        End Select

        GetPass = str.ToString()

    End Function

    ' ******************************************************
    ' 一般取得
    ' ******************************************************
    Public Function GetValue(ByVal Section As String, ByVal Entry As String) As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType()

        Call GetPrivateProfileString(Section, Entry, "", str, 512, ini)

        GetValue = str.ToString()

    End Function

    ' ******************************************************
    ' エラーメッセージの取得
    ' ******************************************************
    Public Function GetErrorMessage(ByVal code As String) As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType()

        Call GetPrivateProfileString("Error", "E" & code, "", str, 512, ini)

        GetErrorMessage = str.ToString()

    End Function

    ' ******************************************************
    ' エラーメッセージの表示
    ' ******************************************************
    Public Sub DispError( _
        ByVal code As String, _
        Optional ByRef target As System.Windows.Forms.TextBox = Nothing, _
        Optional ByRef e As System.ComponentModel.CancelEventArgs = Nothing _
    )

        If Not target Is Nothing Then
            target.SelectAll()
            target.Focus()
        End If
        If Not e Is Nothing Then
            e.Cancel = True
        End If
        Dim str As String = Me.GetErrorMessage(code)
        MessageBox.Show(str & "　　　", "R205", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

End Class

Public Class DEBUG


    Public path As String
    Public handle As StreamWriter
    Public handleRead As StreamReader

    ' ********************************************************
    ' (コンストラクタの定義)( Sub で定義する )
    ' ********************************************************
    Public Sub New(ByVal Messaege As String)

#If DEBUG Then
        path = Application.StartupPath()
        path &= "\debug.log"

        handle = New StreamWriter(path, True)
        Me.Write(Application.ExecutablePath & " を開始しました")
        Me.Write("インスタンス作成時:" & Messaege)

        Dim pc As String = System.Net.Dns.GetHostName()
        Dim ip As String = System.Net.Dns.GetHostEntry(pc).AddressList(0).ToString()
        Dim login As String = Environment.UserName
        Me.Write("****** " & login & vbTab & pc & vbTab & ip & " ******")
#End If

    End Sub

    ' ********************************************************
    ' 書き込み
    ' ********************************************************
    Public Sub Write(Optional ByVal Messaege As String = "")

#If DEBUG Then
        Dim str As String = DateTime.Now.ToString()
        str &= vbTab & Messaege

        handle.WriteLine(str)
#End If

    End Sub

    ' ********************************************************
    ' 終了
    ' ********************************************************
    Public Sub Quit()

#If DEBUG Then
        Me.Write(Application.ExecutablePath & " を終了します")
        Me.Write()
        handle.Flush()
        handle.Close()
#End If

    End Sub

    ' ********************************************************
    ' 読み込み用に変更
    ' ********************************************************
    Public Sub ChangeRead()

#If DEBUG Then
        Me.Write("ログを読み込み用に変更します")
        handle.Flush()
        handle.Close()

        handleRead = New StreamReader(path, Encoding.UTF8)
#End If

    End Sub

    ' ********************************************************
    ' 読み込みを終了して書き込みモードに戻る
    ' ********************************************************
    Public Sub EndRead()

#If DEBUG Then

        handleRead.Close()
        handleRead.Dispose()

        handle = New StreamWriter(path, True)
        Me.Write("書き込みを再開します")
#End If

    End Sub

End Class
