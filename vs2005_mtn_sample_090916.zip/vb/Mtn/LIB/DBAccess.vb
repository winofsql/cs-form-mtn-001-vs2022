' ******************************************************
' �y�f�[�^�x�[�X�����p�N���X�z
'
' �ړI�@�@�@ : �ėp
' �쐬�ҁ@�@ : lightbox
' �t�@�C���� : DBAccess.vb
' ******************************************************

Imports System.Data.Odbc

Public Class DB

    ' �ڑ��I�u�W�F�N�g
    Public myCon As OdbcConnection = New OdbcConnection
    ' �R�}���h�I�u�W�F�N�g
    Private myCommand As OdbcCommand = New OdbcCommand
    ' �ڑ�������
    Public strCon As String = String.Empty

    Public DBType As Integer = 1

    ' ********************************************************
    ' (�R���X�g���N�^�̒�`)( Sub �Œ�`���� )
    ' ********************************************************
    Public Sub New( _
    ByVal type As Integer, _
    ByVal sv As String, _
    ByVal db As String, _
    ByVal user As String, _
    ByVal pass As String)

        Me.DBType = type

        Select Case Me.DBType
            Case 1
                strCon = String.Format( _
                "Driver={{MySQL ODBC 3.51 Driver}};" + _
                "SERVER={0};" + _
                "DATABASE={1};" + _
                "UID={2};" + _
                "PWD={3}", sv, db, user, pass)
            Case 2
                strCon = String.Format( _
                "Driver={{Microsoft ODBC for Oracle}};" + _
                "SERVER={0};" + _
                "UID={2};" + _
                "PWD={3}", sv, db, user, pass)
            Case Else
        End Select

    End Sub

    ' ********************************************************
    ' (�ڑ�����)
    ' ********************************************************
    Public Function Connect() As Boolean

        Connect = True

        ' �ڑ�������Z�b�g
        myCon.ConnectionString = strCon

        ' ====================================================
        ' (��O����)
        ' ====================================================
        Try
            ' �ڑ�
            myCon.Open()
        Catch ex As Exception
            Connect = False
            MessageBox.Show(ex.Message)
        End Try

        ' �R�}���h�I�u�W�F�N�g��ڑ��Ɋ֌W�t����
        myCommand.Connection = myCon

    End Function

    ' ********************************************************
    ' ���s
    ' ********************************************************
    Public Function Execute(ByVal str As String) As Integer

        If Me.DBType = 2 Then
            str = str.Replace("`", """")
        End If

        Dim myCommand As New OdbcCommand
        myCommand.CommandText = str
        myCommand.Connection = myCon
        Execute = myCommand.ExecuteNonQuery()

    End Function

    ' ********************************************************
    ' �ǂݍ��� ( �߂�l�� OdbcDataReader )
    ' ********************************************************
    Public Function Query(ByVal str As String) As OdbcDataReader

        If Me.DBType = 2 Then
            str = str.Replace("`", """")
        End If

        Dim myCommand As New OdbcCommand
        myCommand.CommandText = str
        myCommand.Connection = myCon
        Dim myReader As OdbcDataReader = Nothing

        myReader = myCommand.ExecuteReader()
        myReader.Read()
        Query = myReader

    End Function

    ' ********************************************************
    ' �񖼂�蕶����l�̎擾
    ' ********************************************************
    Public Function Value(ByRef myReader As OdbcDataReader, ByVal str As String) As String

        Dim fld As Integer = 0
        fld = myReader.GetOrdinal(str)
        On Error Resume Next
        Value = myReader.GetString(fld)
        If Err.Number <> 0 Then
            Value = ""
        End If
        On Error GoTo 0

    End Function

    ' ********************************************************
    ' (�ڑ���������)
    ' ********************************************************
    Public Sub Close()

        myCon.Close()

    End Sub


End Class

' ******************************************************
' �y�₢���킹�p DataGridView �����p�N���X�z
' �ړI�@�@�@ : �L�[�R�[�h�Q�Ɨp
' �쐬�ҁ@�@ : lightbox
' �t�@�C���� : DBAccess.vb
' ******************************************************

Public Class LboxGrid

    Public _Con As OdbcConnection
    Public _Grid As DataGridView
    Public Query As String = ""
    Public Command As OdbcCommand = Nothing
    Public Adapter As OdbcDataAdapter = Nothing
    Public Dset As DataSet = Nothing

    Public Sub New( _
        ByVal Con As OdbcConnection, _
        ByVal str As String, _
        ByVal dv As DataGridView _
        )

        Me._Con = Con
        Me._Grid = dv

        Query = str
        Command = New OdbcCommand(Query, Me._Con)
        Adapter = New OdbcDataAdapter(Command)
        Dset = New DataSet()

        ' DB����
        Adapter.Fill(Dset, "myTable")

        ' �O���b�h�֓K�p
        Me._Grid.DataSource = Dset

        ' �\��
        Me._Grid.DataMember = "myTable"

        ' �J��������
        Me._Grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells

        ' -------------------------------------------------
        ' �O���b�h�@�\�����ݒ�
        ' -------------------------------------------------
        Me._Grid.MultiSelect = False
        Me._Grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        Me._Grid.Rows(0).Selected = True

    End Sub

    Public Sub Reload( _
        ByVal str As String _
        )

        Query = str

        Command = New OdbcCommand(Query, Me._Con)
        Adapter = New OdbcDataAdapter(Command)
        Dset = New DataSet()

        Adapter.Fill(Dset, "myTable")

        ' �O���b�h�֓K�p
        Me._Grid.DataSource = Dset

        ' -------------------------------------------------
        ' �O���b�h�@�\�����ݒ�
        ' -------------------------------------------------
        Me._Grid.Rows(0).Selected = True

    End Sub

End Class
