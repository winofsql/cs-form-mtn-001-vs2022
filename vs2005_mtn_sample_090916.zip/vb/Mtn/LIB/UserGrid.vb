﻿Public Class UserGrid

    Public nCurrentRow As Integer = -1

    ' ******************************************************
    ' カラム追加
    ' ******************************************************
    Public Sub AddColumn(ByVal strName As String, ByVal strTitle As String)

        Me.Columns.Add(strName, strTitle)

    End Sub

    ' ******************************************************
    ' カラム幅追加
    ' ******************************************************
    Public Sub SetColumnWidth(ByVal strName As String, ByVal nWidth As Integer)

        Me.Columns(strName).Width = nWidth

    End Sub

    ' ******************************************************
    ' 行追加
    ' ******************************************************
    Public Sub AddRow()

        nCurrentRow = Me.Rows.Add(1)

    End Sub

    ' ******************************************************
    ' カラムデータ変更
    ' ******************************************************
    Public Sub SetColumnText(ByVal nIndex As Integer, _
    ByVal strName As String, ByVal strText As String)

        Me.Rows(nIndex).Cells(strName).Value = strText

    End Sub

    ' ******************************************************
    ' カラムデータ変更
    ' ******************************************************
    Public Sub SetColumnText(ByVal strName As String, ByVal strText As String)

        Me.Rows(nCurrentRow).Cells(strName).Value = strText

    End Sub

    ' ******************************************************
    ' カラムを表示・非表示
    ' ******************************************************
    Public Sub SetColumnVisible(ByVal strName As String, ByVal bFlg As Boolean)

        Me.Columns(strName).Visible = bFlg

    End Sub

    ' ******************************************************
    ' 行をすべて削除
    ' ******************************************************
    Public Sub Clear()

        Dim count As Integer = Me.Rows.Count
        Dim i As Integer

        For i = count - 1 To 0 Step -1
            Me.Rows.RemoveAt(i)
        Next

    End Sub

    ' ******************************************************
    ' 初期化
    ' ******************************************************
    Public Sub Reset()

        Me.Columns.Clear()

    End Sub

    ' ******************************************************
    ' サイズ調整メソッド
    ' ******************************************************
    Public Sub ParentFit(ByVal TargetForm As System.Windows.Forms.Form)

        Me.Left = _SizeLeft
        Me.Top = _SizeTop
        Me.Width = TargetForm.ClientRectangle.Width - _SizeLeft - _SizeRight
        Me.Height = TargetForm.ClientRectangle.Height - _SizeTop - _SizeBottom

    End Sub


    Private _SizeLeft As Integer = 0
    Private _SizeTop As Integer = 0
    Private _SizeRight As Integer = 0
    Private _SizeBottom As Integer = 0
    ' ******************************************************
    ' サイズ調整用位置プロパティ
    ' ******************************************************
    Public Property SizeLeft() As Integer
        Get
            Return _SizeLeft
        End Get
        Set(ByVal value As Integer)
            _SizeLeft = value
        End Set
    End Property
    Public Property SizeRight() As Integer
        Get
            Return _SizeRight
        End Get
        Set(ByVal value As Integer)
            _SizeRight = value
        End Set
    End Property
    Public Property SizeTop() As Integer
        Get
            Return _SizeTop
        End Get
        Set(ByVal value As Integer)
            _SizeTop = value
        End Set
    End Property
    Public Property SizeBottom() As Integer
        Get
            Return _SizeBottom
        End Get
        Set(ByVal value As Integer)
            _SizeBottom = value
        End Set
    End Property

End Class
