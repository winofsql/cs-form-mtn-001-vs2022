' ******************************************************
' �y���ʊ֐��z
'
' �ړI�@�@�@ : �ėp
' �쐬�ҁ@�@ : lightbox
' �t�@�C���� : ���ʊ֐�.vb
' ******************************************************

Imports System.IO
Imports System.Text
Imports System.Runtime.InteropServices

Module ZModule

    ' ******************************************************
    ' ini �t�@�C����������
    ' ******************************************************
    <DllImport("Kernel32.dll", CharSet:=CharSet.Auto)> _
    Public Function WritePrivateProfileString( _
                ByVal lpAppName As String, _
                ByVal lpKeyName As String, _
                ByVal lpString As String, _
                ByVal lpFileName As String) As Integer
    End Function

    ' ******************************************************
    ' ini �t�@�C���ǂݍ���
    ' ******************************************************
    <DllImport("Kernel32.dll", CharSet:=CharSet.Auto)> _
    Public Function GetPrivateProfileString( _
                ByVal lpAppName As String, _
                ByVal lpKeyName As String, _
                ByVal lpDefault As String, _
                ByVal lpReturnedString As StringBuilder, _
                ByVal nSize As Integer, _
                ByVal lpFileName As String) As Integer
    End Function

    ' ******************************************************
    ' SQL������쐬�p( �V���O���N�I�[�g )
    ' ******************************************************
    Function SS(ByVal str As String) As String

        str = str.Replace("'", "''")
        SS = "'" & str & "'"

    End Function

    ' ******************************************************
    ' �e�L�X�g�t�@�C����蕶������擾( �P��u������ )
    ' ******************************************************
    Function GetSql(ByVal path As String, ByVal rpl As String) As String

        Dim hReader As New System.IO.StreamReader(path, System.Text.Encoding.Default)
        Dim myQuery As String = hReader.ReadToEnd()
        hReader.Close()

        myQuery = System.Text.RegularExpressions.Regex.Replace( _
            myQuery, "([^\n-]*)--[^\n]*\n", "$1" & vbLf _
        )

        GetSql = myQuery.Replace("$01", rpl)

    End Function

    ' ******************************************************
    ' �e�L�X�g�t�@�C����蕶������擾( �z��u�������@ )
    ' ******************************************************
    Function GetSql(ByVal path As String, ByVal rpl As String()) As String

        Dim hReader As New System.IO.StreamReader(path, System.Text.Encoding.Default)
        Dim myQuery As String = hReader.ReadToEnd()
        hReader.Close()

        myQuery = System.Text.RegularExpressions.Regex.Replace( _
            myQuery, "([^\n-]*)--[^\n]*\n", "$1" & vbLf _
        )

        Dim len As Integer = rpl.Length()
        Dim i As Integer
        Dim str As String = ""

        For i = 0 To len - 1
            str = String.Format("${0:00}", i + 1)
            myQuery = myQuery.Replace(str, rpl(i))
        Next

        GetSql = myQuery

    End Function

    ' ******************************************************
    ' �e�L�X�g�t�@�C����蕶������擾( �z��u�������A )
    ' ******************************************************
    Function GetSql2(ByVal path As String, ByVal rpl As String()) As String

        Dim hReader As New System.IO.StreamReader(path, System.Text.Encoding.Default)
        Dim myQuery As String = hReader.ReadToEnd()
        hReader.Close()

        myQuery = System.Text.RegularExpressions.Regex.Replace( _
            myQuery, "([^\n-]*)--[^\n]*\n", "$1" & vbLf _
        )

        GetSql2 = String.Format(myQuery, rpl)

    End Function


    ' ******************************************************
    ' �\�����[�V�����f�B���N�g�����擾
    ' ******************************************************
    Function GetSlnDir() As String

        GetSlnDir = Path.GetDirectoryName(Application.StartupPath)
        GetSlnDir = Path.GetDirectoryName(GetSlnDir)
        GetSlnDir = Path.GetDirectoryName(GetSlnDir)

    End Function

    ' ******************************************************
    ' ���l�`�F�b�N
    ' ******************************************************
    Function CheckInt(ByVal str As String) As Boolean

        CheckInt = True
        Try
            Dim num As Integer = Integer.Parse(str)
        Catch e As Exception
            CheckInt = False
        End Try

    End Function





    ' ******************************************************
    ' �ڑ� DB �̎�ނ��擾
    ' ******************************************************
    Function GetDBType(ByVal ini As String) As Integer

        Dim str As StringBuilder = New StringBuilder(512)

        Call GetPrivateProfileString("MTN", "ConnetctType", "1", str, 512, ini)
        GetDBType = Integer.Parse(str.ToString())

    End Function

    ' ******************************************************
    ' �ڑ� Server ���擾
    ' ******************************************************
    Function GetServer(ByVal ini As String) As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType(ini)

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "Server", "localhost", str, 512, ini)
            Case 2
                Call GetPrivateProfileString("Oracle", "Server", "localhost/ORCL", str, 512, ini)

        End Select

        GetServer = str.ToString()

    End Function

    ' ******************************************************
    ' �ڑ� Server ���擾
    ' ******************************************************
    Function GetDB(ByVal ini As String) As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType(ini)

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "Database", "", str, 512, ini)
            Case 2
                str.Append("")

        End Select

        GetDB = str.ToString()

    End Function

    ' ******************************************************
    ' �ڑ� Server ���擾
    ' ******************************************************
    Function GetUser(ByVal ini As String) As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType(ini)

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "User", "", str, 512, ini)
            Case 2
                Call GetPrivateProfileString("Oracle", "User", "", str, 512, ini)

        End Select

        GetUser = str.ToString()

    End Function

    ' ******************************************************
    ' �ڑ� Server ���擾
    ' ******************************************************
    Function GetPass(ByVal ini As String) As String

        Dim str As StringBuilder = New StringBuilder(512)
        Dim nType As Integer = GetDBType(ini)

        Select Case nType
            Case 1
                Call GetPrivateProfileString("MySQL", "Password", "", str, 512, ini)
            Case 2
                Call GetPrivateProfileString("Oracle", "Password", "", str, 512, ini)

        End Select

        GetPass = str.ToString()

    End Function

    ' ******************************************************
    ' �f�o�b�O���O( OPEN : WRITE : CLOSE )
    ' ******************************************************
    Sub DebugLog(ByVal str As String)

#If DEBUG Then
        Dim strPath = Application.StartupPath()
        strPath &= "\debug.log"

        Dim OutFile As StreamWriter = New StreamWriter(strPath, True)
        OutFile.WriteLine(DateTime.Now.ToString() & vbTab & str)
        OutFile.Close()
#End If

    End Sub

End Module
