Public Class UserControl

    ' ******************************************************
    ' Valdating �R���g���[���t���O
    ' ******************************************************
    Public Shared validateNone As Boolean = False

    Protected Overrides Sub OnValidating(ByVal e As System.ComponentModel.CancelEventArgs)

        ' ******************************************************
        ' validateNone �� True �Ȃ�΁AValdating �͔������Ȃ�
        ' ******************************************************
        If Not validateNone Then
            MyBase.OnValidating(e)
        End If

    End Sub

    Protected Overrides Sub OnValidated(ByVal e As System.EventArgs)

        ' ******************************************************
        ' validateNone �� True �Ȃ�΁AValidated �͔������Ȃ�
        ' ******************************************************
        If Not validateNone Then
            MyBase.OnValidated(e)
        End If

    End Sub

    Private _DataType As Integer = 0

    ' ******************************************************
    ' �f�[�^�^( �v���p�e�B�����e�X�g )
    ' ******************************************************
    <System.ComponentModel.Description("0:������" & vbCrLf & "1:����"), _
    System.ComponentModel.DefaultValue(0)> _
        Public Property DataType() As Integer
        Get
            Return _DataType
        End Get
        Set(ByVal value As Integer)
            _DataType = value
        End Set
    End Property

End Class
