﻿' ******************************************************
' 【主なイベント処理】
'
' 目的　　　 : メール受信ダイアログの主処理
' 作成者　　 : lightbox
' ファイル名 : 03_メール受信イベント.vb
' ******************************************************

Imports System.Windows.Forms

Partial Class MailDialog2

    ' ******************************************************
    ' OK
    ' ******************************************************
    Private Sub OK_Button_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles OK_Button.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()

    End Sub

    ' ******************************************************
    ' Cancel
    ' ******************************************************
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub


End Class
