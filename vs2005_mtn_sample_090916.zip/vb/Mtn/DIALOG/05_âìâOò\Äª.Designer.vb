﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ログダイアログ
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ログデータ = New Mtn.UserGrid
        CType(Me.ログデータ, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ログデータ
        '
        Me.ログデータ.AllowUserToAddRows = False
        Me.ログデータ.AllowUserToDeleteRows = False
        Me.ログデータ.AllowUserToOrderColumns = True
        Me.ログデータ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ログデータ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ログデータ.Location = New System.Drawing.Point(18, 62)
        Me.ログデータ.MultiSelect = False
        Me.ログデータ.Name = "ログデータ"
        Me.ログデータ.ReadOnly = True
        Me.ログデータ.RowTemplate.Height = 21
        Me.ログデータ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ログデータ.Size = New System.Drawing.Size(684, 386)
        Me.ログデータ.SizeBottom = 50
        Me.ログデータ.SizeLeft = 0
        Me.ログデータ.SizeRight = 0
        Me.ログデータ.SizeTop = 50
        Me.ログデータ.TabIndex = 0
        '
        'ログダイアログ
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(737, 536)
        Me.Controls.Add(Me.ログデータ)
        Me.MinimizeBox = False
        Me.Name = "ログダイアログ"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "_05_ログ表示"
        CType(Me.ログデータ, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ログデータ As Mtn.UserGrid

End Class
