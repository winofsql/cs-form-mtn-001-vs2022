﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Browser
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.IE = New System.Windows.Forms.WebBrowser
        Me.ステータス = New System.Windows.Forms.StatusStrip
        Me.通常ラベル = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.HEAD表示ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.テキスト = New System.Windows.Forms.TextBox
        Me.ステータス.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'IE
        '
        Me.IE.Location = New System.Drawing.Point(0, 27)
        Me.IE.MinimumSize = New System.Drawing.Size(20, 20)
        Me.IE.Name = "IE"
        Me.IE.Size = New System.Drawing.Size(773, 320)
        Me.IE.TabIndex = 0
        '
        'ステータス
        '
        Me.ステータス.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.通常ラベル})
        Me.ステータス.Location = New System.Drawing.Point(0, 532)
        Me.ステータス.Name = "ステータス"
        Me.ステータス.Size = New System.Drawing.Size(773, 22)
        Me.ステータス.TabIndex = 5
        Me.ステータス.Text = "StatusStrip1"
        '
        '通常ラベル
        '
        Me.通常ラベル.Name = "通常ラベル"
        Me.通常ラベル.Size = New System.Drawing.Size(0, 17)
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HEAD表示ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(773, 24)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HEAD表示ToolStripMenuItem
        '
        Me.HEAD表示ToolStripMenuItem.Name = "HEAD表示ToolStripMenuItem"
        Me.HEAD表示ToolStripMenuItem.Size = New System.Drawing.Size(72, 20)
        Me.HEAD表示ToolStripMenuItem.Text = "HEAD表示"
        '
        'テキスト
        '
        Me.テキスト.Location = New System.Drawing.Point(11, 368)
        Me.テキスト.Multiline = True
        Me.テキスト.Name = "テキスト"
        Me.テキスト.Size = New System.Drawing.Size(750, 145)
        Me.テキスト.TabIndex = 7
        '
        'Browser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(773, 554)
        Me.Controls.Add(Me.テキスト)
        Me.Controls.Add(Me.ステータス)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.IE)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Browser"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "ブラウザ"
        Me.ステータス.ResumeLayout(False)
        Me.ステータス.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents IE As System.Windows.Forms.WebBrowser
    Friend WithEvents ステータス As System.Windows.Forms.StatusStrip
    Friend WithEvents 通常ラベル As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents HEAD表示ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents テキスト As System.Windows.Forms.TextBox

End Class
