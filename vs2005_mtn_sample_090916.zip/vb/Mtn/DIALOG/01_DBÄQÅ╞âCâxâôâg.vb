﻿' ******************************************************
' 【主なイベント処理】
'
' 目的　　　 : DB参照ダイアログの主処理
' 作成者　　 : lightbox
' ファイル名 : 01_DB参照イベント.vb
' ******************************************************

Imports System.Data.Odbc
Imports System.Windows.Forms

Partial Class View

    ' ******************************************************
    ' セルをダブルクリック( カレント行処理 )
    ' ******************************************************
    Private Sub 問合せ_CellDoubleClick(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles 問合せ.CellDoubleClick

        If e.RowIndex >= 0 And e.ColumnIndex >= 0 Then
            Form1.社員コード.Text = 問合せ.Rows(e.RowIndex).Cells(0).Value
            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()
        End If

    End Sub

    ' ******************************************************
    ' 行が選択された状態での ENTER キーの処理
    ' ******************************************************
    Private Sub 問合せ_KeyDown(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.KeyEventArgs) Handles 問合せ.KeyDown

        If e.KeyCode = Keys.Enter Then

            Dim nRow As Integer = Me.問合せ.SelectedRows.Item(0).Index
            Form1.社員コード.Text = 問合せ.Rows(nRow).Cells(0).Value
            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()

        End If

    End Sub

    ' ******************************************************
    ' テスト用ボタン
    ' ******************************************************
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        My.Application.Debug.ChangeRead()

        ' ファイルの最後まで読み込む
        Dim stBuffer As String = My.Application.Debug.handleRead.ReadToEnd()
        MsgBox(stBuffer)

        My.Application.Debug.EndRead()

        Grid.Reload("SELECT * FROM 商品マスタ")

    End Sub

End Class
