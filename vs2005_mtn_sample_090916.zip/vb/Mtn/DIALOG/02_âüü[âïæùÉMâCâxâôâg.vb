﻿' ******************************************************
' 【主なイベント処理】
'
' 目的　　　 : メール送信ダイアログの主処理
' 作成者　　 : lightbox
' ファイル名 : 02_メール送信イベント.vb
' ******************************************************

Imports System.Windows.Forms
Imports System.Net.Mail

Partial Class MailDialog

    ' ******************************************************
    ' OK
    ' ******************************************************
    Private Sub OK_Button_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles 送信.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK

        Call SendMail()

        Me.Close()
    End Sub

    ' ******************************************************
    ' Cancel
    ' ******************************************************
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub


    ' ******************************************************
    ' ダイアログ内部専用メソッド
    ' ******************************************************
    Private Function SendMail() As String

        Dim MailINI As String = Application.StartupPath & "\mail.ini"
        Dim mail As INI = New INI(MailINI)
        Dim Server As String = mail.GetValue("SMTP", "Server")
        Dim Port As String = mail.GetValue("SMTP", "Port")
        Dim User As String = mail.GetValue("SMTP", "User")
        Dim DisplayUser As String = mail.GetValue("SMTP", "DisplayUser")
        Dim DisplayUserAddress As String = mail.GetValue("SMTP", "DisplayUserAddress")
        Dim Encoding As String = mail.GetValue("SMTP", "Encoding")


        'MailMessageの基本設定
        Dim mailmsg As New MailMessage()

        mailmsg.BodyEncoding = System.Text.Encoding.GetEncoding(Encoding)

        '表示ユーザ( 固定 )
        mailmsg.From = New MailAddress(MailHeadTextEncode(DisplayUser) & " " & _
            "<" & DisplayUserAddress & ">")

        '宛先( 入力 : 日本語は使用しない前提 )
        mailmsg.To.Add(New MailAddress(Me.宛先.Text))

        '件名( 入力 )
        mailmsg.Subject = MailHeadTextEncode(Me.件名.Text)

        '本文( 入力 )
        mailmsg.Body = Me.本文.Text


        'メールの配達が遅れたとき、失敗したとき、正常に配達されたときに通知する
        mailmsg.DeliveryNotificationOptions = _
            System.Net.Mail.DeliveryNotificationOptions.Delay Or _
            System.Net.Mail.DeliveryNotificationOptions.OnFailure Or _
            System.Net.Mail.DeliveryNotificationOptions.OnSuccess

        Dim sc As New SmtpClient(Server, Port)
        sc.UseDefaultCredentials = False
        sc.Credentials = New System.Net.NetworkCredential(User, Me.パスワード.Text)

        ' メールがすぐに送信されない場合の対処
        sc.ServicePoint.MaxIdleTime = 1000

        'メッセージを送信する
        sc.Send(mailmsg)

        '後始末
        mailmsg.Dispose()

        SendMail = ""

    End Function

    ' ******************************************************
    ' メール用日本語処理( 改行コード処理は行っていません )
    ' ******************************************************
    Private Function MailHeadTextEncode(ByVal str As String)

        Dim source() As Byte = {}, encoded() As Byte = {}

        ' 内部コードは Unicode
        Dim sourceEncoding As System.Text.Encoding = System.Text.Encoding.Unicode

        ' 対象文字列をバイト配列に変換
        source = sourceEncoding.GetBytes(str)
        ' Unicode を JIS に変換
        encoded = System.Text.Encoding.Convert( _
            sourceEncoding, System.Text.Encoding.GetEncoding("iso-2022-jp"), source)

        ' Base64 変換後エリア
        Dim base64String As String

        ' JIS を Base64 に変換
        base64String = System.Convert.ToBase64String(encoded, 0, encoded.Length)

        ' メールヘッダ用フォーマットにして返す
        MailHeadTextEncode = "=?ISO-2022-JP?B?" & base64String & "?="

    End Function

End Class
