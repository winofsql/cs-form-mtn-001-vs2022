' ******************************************************
' �y���[����M�p�_�C�A���O�z
'
' �ړI�@�@�@ : basp21 �Ń��[������M����
' �쐬�ҁ@�@ : lightbox
' �t�@�C���� : 03_���[����M.vb
' ******************************************************

Imports System.Windows.Forms
Imports myCom

Public Class MailDialog2

    Dim basp As Basp21 = Nothing

    ' ******************************************************
    ' ��ʏ����ݒ�
    ' ******************************************************
    Private Sub MailDialog2_Load(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load

        Grid.AddColumn("Subject", "����")
        Grid.AddColumn("From", "�����o�l")
        Grid.AddColumn("Date", "���t")

        basp = New Basp21()

    End Sub

    ' ******************************************************
    ' �O���b�h�̃T�C�Y����
    ' ******************************************************
    Private Sub View_SizeChanged(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles Me.SizeChanged

        Me.Grid.ParentFit(Me)

    End Sub

    ' ******************************************************
    ' ���[���ꗗ
    ' ******************************************************
    Private Sub Button1_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button1.Click


        Dim ret As Object = basp.RcvMail("localhost", "lightbox", "trustno1", "LIST", ">" & GetSlnDir() & "\rcvmail")

        If ret <> "" Then
            MsgBox(ret)
        Else
            Dim data As String = ""
            Dim str As String()
            Dim delimStr As String = vbTab
            Dim delimiter As Char() = delimStr.ToCharArray()

            Grid.Clear()

            For Each data In ret
                Me.Grid.AddRow()
                str = data.Split(delimiter)
                Me.Grid.SetColumnText("Subject", str(0))
                Me.Grid.SetColumnText("From", str(1))
                Me.Grid.SetColumnText("Date", str(2))
            Next

            Me.Grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
        End If

    End Sub

End Class
