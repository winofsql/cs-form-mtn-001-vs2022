﻿Imports System.Windows.Forms

Public Class ログダイアログ

    ' ******************************************************
    ' 画面初期設定
    ' ******************************************************
    Private Sub MailDialog2_Load(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load

        ログデータ.AddColumn("Date", "日付")
        ログデータ.AddColumn("Time", "時間")
        ログデータ.AddColumn("Message", "メッセージ")

        My.Application.Debug.ChangeRead()
        Dim str As String
        Dim data() As String
        Dim dataDate() As String
        Dim delimiter As Char() = {}
        Dim i As Integer

        Do While Not My.Application.Debug.handleRead.EndOfStream

            str = My.Application.Debug.handleRead.ReadLine()
            ログデータ.AddRow()

            delimiter = vbTab.ToCharArray()
            data = str.Split(delimiter)

            delimiter = " ".ToCharArray()
            dataDate = data(0).Split(delimiter)

            ログデータ.SetColumnText("Date", dataDate(0))
            ログデータ.SetColumnText("Time", dataDate(1))

            str = ""
            For i = 1 To data.GetUpperBound(0)
                If str <> "" Then
                    str += " "
                End If
                str += data(i)
            Next
            ログデータ.SetColumnText("Message", str)
            If str = "スタートアップを開始しました" Then
                ログデータ.Rows(ログデータ.nCurrentRow).Cells("Message").Style.BackColor = Color.Aqua
            End If

        Loop

        My.Application.Debug.EndRead()

    End Sub

    ' ******************************************************
    ' グリッドのサイズ調整
    ' ******************************************************
    Private Sub View_SizeChanged(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles Me.SizeChanged

        Me.ログデータ.ParentFit(Me)

    End Sub

End Class
