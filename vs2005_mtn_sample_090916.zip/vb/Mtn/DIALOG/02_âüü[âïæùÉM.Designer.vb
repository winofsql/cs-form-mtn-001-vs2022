﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MailDialog
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.送信 = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.宛先 = New System.Windows.Forms.TextBox
        Me.宛先_Label = New System.Windows.Forms.Label
        Me.本文 = New System.Windows.Forms.TextBox
        Me.件名 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.パスワード = New Mtn.UserControl
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.送信, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(409, 383)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 27)
        Me.TableLayoutPanel1.TabIndex = 4
        '
        '送信
        '
        Me.送信.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.送信.Location = New System.Drawing.Point(3, 3)
        Me.送信.Name = "送信"
        Me.送信.Size = New System.Drawing.Size(67, 21)
        Me.送信.TabIndex = 0
        Me.送信.Text = "送信"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 21)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "キャンセル"
        '
        '宛先
        '
        Me.宛先.Location = New System.Drawing.Point(104, 64)
        Me.宛先.Name = "宛先"
        Me.宛先.Size = New System.Drawing.Size(421, 19)
        Me.宛先.TabIndex = 2
        '
        '宛先_Label
        '
        Me.宛先_Label.AutoSize = True
        Me.宛先_Label.Location = New System.Drawing.Point(46, 67)
        Me.宛先_Label.Name = "宛先_Label"
        Me.宛先_Label.Size = New System.Drawing.Size(29, 12)
        Me.宛先_Label.TabIndex = 1
        Me.宛先_Label.Text = "宛先"
        '
        '本文
        '
        Me.本文.Location = New System.Drawing.Point(37, 125)
        Me.本文.Multiline = True
        Me.本文.Name = "本文"
        Me.本文.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.本文.Size = New System.Drawing.Size(489, 222)
        Me.本文.TabIndex = 3
        '
        '件名
        '
        Me.件名.Location = New System.Drawing.Point(37, 25)
        Me.件名.Name = "件名"
        Me.件名.Size = New System.Drawing.Size(488, 19)
        Me.件名.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(46, 97)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "パスワード"
        '
        'パスワード
        '
        Me.パスワード.Location = New System.Drawing.Point(104, 94)
        Me.パスワード.Name = "パスワード"
        Me.パスワード.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.パスワード.Size = New System.Drawing.Size(143, 19)
        Me.パスワード.TabIndex = 5
        '
        'MailDialog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(567, 421)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.パスワード)
        Me.Controls.Add(Me.件名)
        Me.Controls.Add(Me.本文)
        Me.Controls.Add(Me.宛先_Label)
        Me.Controls.Add(Me.宛先)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MailDialog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "メール送信"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents 送信 As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents 宛先 As System.Windows.Forms.TextBox
    Friend WithEvents 宛先_Label As System.Windows.Forms.Label
    Friend WithEvents 本文 As System.Windows.Forms.TextBox
    Friend WithEvents 件名 As System.Windows.Forms.TextBox
    Friend WithEvents パスワード As Mtn.UserControl
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
