﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class View
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.閉じる = New System.Windows.Forms.Button
        Me.問合せ = New Mtn.UserGrid
        CType(Me.問合せ, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(35, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 21)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        '閉じる
        '
        Me.閉じる.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.閉じる.Location = New System.Drawing.Point(383, 14)
        Me.閉じる.Name = "閉じる"
        Me.閉じる.Size = New System.Drawing.Size(84, 19)
        Me.閉じる.TabIndex = 3
        Me.閉じる.Text = "閉じる"
        Me.閉じる.UseVisualStyleBackColor = True
        Me.閉じる.Visible = False
        '
        '問合せ
        '
        Me.問合せ.AllowUserToAddRows = False
        Me.問合せ.AllowUserToDeleteRows = False
        Me.問合せ.AllowUserToOrderColumns = True
        Me.問合せ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.問合せ.Location = New System.Drawing.Point(3, 55)
        Me.問合せ.MultiSelect = False
        Me.問合せ.Name = "問合せ"
        Me.問合せ.ReadOnly = True
        Me.問合せ.RowTemplate.Height = 21
        Me.問合せ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.問合せ.Size = New System.Drawing.Size(510, 315)
        Me.問合せ.SizeBottom = 0
        Me.問合せ.SizeLeft = 0
        Me.問合せ.SizeRight = 0
        Me.問合せ.SizeTop = 0
        Me.問合せ.TabIndex = 4
        '
        'View
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(525, 393)
        Me.Controls.Add(Me.問合せ)
        Me.Controls.Add(Me.閉じる)
        Me.Controls.Add(Me.Button1)
        Me.KeyPreview = True
        Me.Name = "View"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "View"
        CType(Me.問合せ, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents 閉じる As System.Windows.Forms.Button
    Friend WithEvents 問合せ As Mtn.UserGrid

End Class
