﻿' ******************************************************
' 【問合せ用ダイアログ】
'
' 目的　　　 : メインフォームから呼び出す参照ダイアログ
' 作成者　　 : lightbox
' ファイル名 : 01_DB参照.vb
' ******************************************************

Imports System.Data.Odbc
Imports System.Windows.Forms

Public Class View

    Public Grid As LboxGrid

    ' ******************************************************
    ' 検索データ初期ロード
    ' ******************************************************
    Private Sub View_Load(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles Me.Load

        Dim Query As String = GetSql(Form1.REQUIRE_SQL, "")
        If Form1.db.DBType = 2 Then
            Query = Query.Replace("`", """")
        End If

        Grid = _
        New LboxGrid( _
            Form1.db.myCon, _
            Query, _
            Me.問合せ _
        )

        Me.問合せ.Columns(5).DefaultCellStyle.Format = "#,##0"
        Me.問合せ.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Me.問合せ.Columns(6).DefaultCellStyle.Format = "#,##0"
        Me.問合せ.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        ' 表示位置は右上
        Dim w As Integer = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width
        Dim x As Integer = w - Me.Width

        Me.Left = x
        Me.Top = 0

    End Sub

    ' ******************************************************
    ' グリッドが表示された時の処理
    ' ******************************************************
    Private Sub View_Shown(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles Me.Shown

        Me.問合せ.Focus()

    End Sub

    ' ******************************************************
    ' グリッドのサイズ調整
    ' ******************************************************
    Private Sub View_SizeChanged(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles Me.SizeChanged

        Me.問合せ.ParentFit(Me)

        ' ******************************************************
        ' 最小化切り替え時の処理
        ' ******************************************************
        If Me.WindowState = FormWindowState.Minimized Then
            Me.Owner.Hide()
        End If
        If Me.WindowState = FormWindowState.Normal Or _
            Me.WindowState = FormWindowState.Maximized Then
            ' 完全にこのダイアログが作成されている場合のみ
            If Me.Visible Then
                Me.Owner.Show()
            End If
        End If

    End Sub

    ' ******************************************************
    ' CancelButton として登録された閉じるボタン
    ' 但し、非表示にすると処理されない
    ' ******************************************************
    Private Sub 閉じる_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles 閉じる.Click

        Me.Close()

    End Sub

    ' ******************************************************
    ' ESC でフォームを閉じる (KeyPreview : true)
    ' 但し、CancelButton が「なし」である必要がある
    ' ******************************************************
    Private Sub View_KeyDown(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.Escape Then

            Me.Close()

        End If

    End Sub

End Class
