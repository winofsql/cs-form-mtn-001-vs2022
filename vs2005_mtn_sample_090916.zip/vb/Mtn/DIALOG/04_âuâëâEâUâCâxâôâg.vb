﻿' ******************************************************
' 【主なイベント処理】
'
' 目的　　　 : ブラウザ内ページ処理ダイアログの主処理
' 作成者　　 : lightbox
' ファイル名 : 04_ブラウザイベント.vb
' ******************************************************

Imports System.Windows.Forms

Partial Class Browser

    ' ******************************************************
    ' メニュー処理
    ' ******************************************************
    Private Sub HEAD表示ToolStripMenuItem_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles HEAD表示ToolStripMenuItem.Click

        Dim str As String = Me.IE.Document.GetElementsByTagName("HEAD")(0).InnerHtml

        Me.テキスト.Text = str

    End Sub


End Class
