﻿' ******************************************************
' 【印刷用専用関数】
'
' 目的　　　 : このプログラムでのみ使用される関数
' 作成者　　 : lightbox
' ファイル名 : 印刷用専用関数.vb
' -----------------------------------------
' (注意)
' サンプルとして見通しの悪いコードとなるので
' 本来すべき完全なクラス化を行っていない
' ******************************************************

Imports System.Drawing.Printing

Partial Class Form1

    ' 印字用フォント
    Private printFont As Font = New Font("HG創英角ﾎﾟｯﾌﾟ体", 12)
    Private printPageMax As Integer = 2
    ' ページポインタ
    Private pageCount As Integer = 0   ' 0 で初期状態を示す
    ' 行ポインタ
    Private rowCount As Integer = 0

    ' ******************************************************
    ' 処理独立の為、Sub で作成( イベントアクション より Call )
    ' ******************************************************
    Public Sub 印刷プレビュー処理()

        ' 印刷用ドキュメント
        Dim pd As PrintDocument = New PrintDocument()

        ' 印刷用ドキュメントに処理イベントを登録
        AddHandler pd.PrintPage, AddressOf pd_PrintPage

        ' プレビュー用のダイアログ
        Dim view As PrintPreviewDialog = New PrintPreviewDialog()
        ' プレビューする 対象をセット
        view.Document = pd

        ' プレビューダイアログの初期化
        view.StartPosition = FormStartPosition.Manual
        view.Left = 0 : view.Top = 0
        view.Width = 800 : view.Height = 400
        ' 拡大率 100% 
        view.PrintPreviewControl.Zoom = 1

        ' プレビュー開始
        view.ShowDialog()

        ' DB 処理終了
        myReader.Close()

        ' 開放
        pd.Dispose()
        view.Dispose()

    End Sub

    ' ******************************************************
    ' 処理イベント
    ' ******************************************************
    Sub pd_PrintPage(ByVal sender As Object, _
    ByVal e As PrintPageEventArgs)


        If pageCount = 0 Then
            ' 印刷処理が開始された事を示す
            pageCount += 1

            ' SQL 準備
            Dim myQuery As String = "select * from 社員マスタ"

            ' 読み出し( myReader は既にカレント行を取得している )
            myReader = db.Query(myQuery)

        End If


        ' 1ページあたりの行数
        Dim linesPerPage As Integer = _
            e.MarginBounds.Height / printFont.GetHeight(e.Graphics)
        ' 左端
        Dim leftMargin As Integer = e.MarginBounds.Left
        ' 先端
        Dim topMargin As Integer = e.MarginBounds.Top

        ' カラム印刷用オブジェクト
        Dim col As New ColPrint(e.Graphics, leftMargin, topMargin, printFont)

        ' ******************************************************
        ' ヘッダ印刷
        ' ******************************************************
        rowCount += 1
        col.Text("CD", 0, rowCount)
        col.Text("氏名", 50, rowCount)
        col.Text("給与", 190, rowCount, 100)
        col.Text("生年月日", 300, rowCount)
        rowCount += 1
        col.Line(0, rowCount, 400)


        ' 印字位置
        Dim xPos As Integer = 0
        Dim yPos As Integer = 0
        Dim bRow As Boolean = True

        linesPerPage = 10

        ' HasRows プロパティは、行があるかどうかのプロパティ
        Do While myReader.HasRows And bRow

            ' 行カウントアップ
            rowCount += 1
            If rowCount > linesPerPage Then
                ' 次ページ有り
                e.HasMorePages = True
                rowCount = 0
                ' ページ数カウントアップ
                pageCount += 1
                ' SUB を終了する
                Exit Sub
            End If

            col.Text(db.Value(myReader, "社員コード"), 0, rowCount)
            col.Text(db.Value(myReader, "氏名"), 50, rowCount)
            col.RightNumber(db.Value(myReader, "給与"), 190, rowCount, 100)
            col.Text(db.Value(myReader, "生年月日"), 300, rowCount)


            ' 次行を取得する
            bRow = myReader.Read()

        Loop

        ' 次ページ無し
        e.HasMorePages = False
        ' 印刷処理の初期化( 次呼ばれても正常に処理される )
        rowCount = 0
        pageCount = 0

    End Sub

    ' ******************************************************
    ' データ出力用プライベートクラス
    ' ******************************************************
    Private Class ColPrint

        Private leftMargin As Integer
        Private topMargin As Integer
        Private Graphic As System.Drawing.Graphics
        Private printFont As Font = Nothing
        Private rowHeight As Integer

        Sub New(ByVal g As System.Drawing.Graphics, _
                ByVal x As Integer, ByVal y As Integer, ByRef f As Font)
            Graphic = g
            leftMargin = x
            topMargin = y
            printFont = f
            rowHeight = printFont.GetHeight(Graphic)
        End Sub

        ' ******************************************************
        ' 単純テキスト
        ' ******************************************************
        Sub Text(ByVal str As String, _
                ByVal x As Integer, ByVal y As Integer)

            Dim xPos As Integer = leftMargin + x
            Dim yPos As Integer = topMargin + (y - 1) * rowHeight

            Graphic.DrawString(str, printFont, Brushes.Black, xPos, yPos)

        End Sub

        ' ******************************************************
        ' 右詰めテキスト( 単純テキストをオーバーロード )
        ' ******************************************************
        Sub Text(ByVal str As String, _
                ByVal x As Integer, ByVal y As Integer, ByVal w As Integer)

            Dim xPos As Integer = leftMargin + x
            Dim yPos As Integer = topMargin + (y - 1) * rowHeight
            ' 四角形オブジェクト
            Dim layoutRectangle = New RectangleF(xPos, yPos, w, printFont.GetHeight(Graphic))
            Dim fmt As New StringFormat
            fmt.Alignment = StringAlignment.Far

            Graphic.DrawString(str, printFont, Brushes.Black, layoutRectangle, fmt)

        End Sub

        ' ******************************************************
        ' 右詰めカンマ編集
        ' ******************************************************
        Sub RightNumber(ByVal str As String, _
                ByVal x As Integer, ByVal y As Integer, ByVal w As Integer)

            Dim xPos As Integer = leftMargin + x
            Dim yPos As Integer = topMargin + (y - 1) * rowHeight
            ' 四角形オブジェクト
            Dim layoutRectangle = New RectangleF(xPos, yPos, w, printFont.GetHeight(Graphic))
            Dim fmt As New StringFormat
            fmt.Alignment = StringAlignment.Far

            str = Integer.Parse(str).ToString("#,##0")
            Graphic.DrawString(str, printFont, Brushes.Black, layoutRectangle, fmt)

        End Sub

        ' ******************************************************
        ' 横線
        ' ******************************************************
        Sub Line(ByVal x As Integer, ByVal y As Integer, ByVal x2 As Integer)

            Dim xPos As Integer = leftMargin + x
            Dim xPos2 As Integer = leftMargin + x2
            Dim yPos As Integer = topMargin + (y - 1) * rowHeight + (rowHeight / 2)

            Graphic.DrawLine(Pens.Black, xPos, yPos, xPos2, yPos)

        End Sub

    End Class

End Class

