﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
		Me.終了 = New System.Windows.Forms.ToolStripMenuItem
		Me.処理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.メール送信 = New System.Windows.Forms.ToolStripMenuItem
		Me.メール受信 = New System.Windows.Forms.ToolStripMenuItem
		Me.ブラウザ表示 = New System.Windows.Forms.ToolStripMenuItem
		Me.印刷プレビュー = New System.Windows.Forms.ToolStripMenuItem
		Me.HELPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.ログ表示 = New System.Windows.Forms.ToolStripMenuItem
		Me.ボディ部 = New System.Windows.Forms.GroupBox
		Me.基本給 = New Mtn.UserControl
		Me.社員名 = New Mtn.UserControl
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label3 = New System.Windows.Forms.Label
		Me.生年月日 = New System.Windows.Forms.DateTimePicker
		Me.更新 = New System.Windows.Forms.Button
		Me.キャンセル = New System.Windows.Forms.Button
		Me.ヘッド部 = New System.Windows.Forms.GroupBox
		Me.社員コード = New Mtn.UserControl
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.確認 = New System.Windows.Forms.Button
		Me.処理区分 = New System.Windows.Forms.ComboBox
		Me.ステータス = New System.Windows.Forms.StatusStrip
		Me.通常ラベル = New System.Windows.Forms.ToolStripStatusLabel
		Me.MenuStrip1.SuspendLayout()
		Me.ボディ部.SuspendLayout()
		Me.ヘッド部.SuspendLayout()
		Me.ステータス.SuspendLayout()
		Me.SuspendLayout()
		'
		'MenuStrip1
		'
		Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.終了, Me.処理ToolStripMenuItem, Me.HELPToolStripMenuItem})
		Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
		Me.MenuStrip1.Name = "MenuStrip1"
		Me.MenuStrip1.Size = New System.Drawing.Size(614, 24)
		Me.MenuStrip1.TabIndex = 3
		Me.MenuStrip1.Text = "MenuStrip1"
		'
		'終了
		'
		Me.終了.Name = "終了"
		Me.終了.Size = New System.Drawing.Size(41, 20)
		Me.終了.Text = "終了"
		'
		'処理ToolStripMenuItem
		'
		Me.処理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.メール送信, Me.メール受信, Me.ブラウザ表示, Me.印刷プレビュー})
		Me.処理ToolStripMenuItem.Name = "処理ToolStripMenuItem"
		Me.処理ToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
		Me.処理ToolStripMenuItem.Text = "処理"
		'
		'メール送信
		'
		Me.メール送信.Name = "メール送信"
		Me.メール送信.Size = New System.Drawing.Size(143, 22)
		Me.メール送信.Text = "メール送信"
		'
		'メール受信
		'
		Me.メール受信.Name = "メール受信"
		Me.メール受信.Size = New System.Drawing.Size(143, 22)
		Me.メール受信.Text = "メール受信"
		'
		'ブラウザ表示
		'
		Me.ブラウザ表示.Name = "ブラウザ表示"
		Me.ブラウザ表示.Size = New System.Drawing.Size(143, 22)
		Me.ブラウザ表示.Text = "ブラウザ"
		'
		'印刷プレビュー
		'
		Me.印刷プレビュー.Name = "印刷プレビュー"
		Me.印刷プレビュー.Size = New System.Drawing.Size(143, 22)
		Me.印刷プレビュー.Text = "印刷プレビュー"
		'
		'HELPToolStripMenuItem
		'
		Me.HELPToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ログ表示})
		Me.HELPToolStripMenuItem.Name = "HELPToolStripMenuItem"
		Me.HELPToolStripMenuItem.Size = New System.Drawing.Size(45, 20)
		Me.HELPToolStripMenuItem.Text = "HELP"
		'
		'ログ表示
		'
		Me.ログ表示.Name = "ログ表示"
		Me.ログ表示.Size = New System.Drawing.Size(117, 22)
		Me.ログ表示.Text = "ログ表示"
		'
		'ボディ部
		'
		Me.ボディ部.Controls.Add(Me.基本給)
		Me.ボディ部.Controls.Add(Me.社員名)
		Me.ボディ部.Controls.Add(Me.Label5)
		Me.ボディ部.Controls.Add(Me.Label4)
		Me.ボディ部.Controls.Add(Me.Label3)
		Me.ボディ部.Controls.Add(Me.生年月日)
		Me.ボディ部.Controls.Add(Me.更新)
		Me.ボディ部.Controls.Add(Me.キャンセル)
		Me.ボディ部.Enabled = False
		Me.ボディ部.Location = New System.Drawing.Point(55, 174)
		Me.ボディ部.Name = "ボディ部"
		Me.ボディ部.Size = New System.Drawing.Size(479, 245)
		Me.ボディ部.TabIndex = 1
		Me.ボディ部.TabStop = False
		Me.ボディ部.Text = "ボディ部"
		'
		'基本給
		'
		Me.基本給.Location = New System.Drawing.Point(121, 102)
		Me.基本給.Name = "基本給"
		Me.基本給.Size = New System.Drawing.Size(82, 19)
		Me.基本給.TabIndex = 3
		Me.基本給.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		'
		'社員名
		'
		Me.社員名.Location = New System.Drawing.Point(121, 63)
		Me.社員名.Name = "社員名"
		Me.社員名.Size = New System.Drawing.Size(184, 19)
		Me.社員名.TabIndex = 1
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Location = New System.Drawing.Point(21, 147)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(53, 12)
		Me.Label5.TabIndex = 4
		Me.Label5.Text = "生年月日"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Location = New System.Drawing.Point(21, 105)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(29, 12)
		Me.Label4.TabIndex = 2
		Me.Label4.Text = "給与"
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Location = New System.Drawing.Point(21, 66)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(29, 12)
		Me.Label3.TabIndex = 0
		Me.Label3.Text = "氏名"
		'
		'生年月日
		'
		Me.生年月日.Location = New System.Drawing.Point(121, 144)
		Me.生年月日.Name = "生年月日"
		Me.生年月日.ShowCheckBox = True
		Me.生年月日.Size = New System.Drawing.Size(183, 19)
		Me.生年月日.TabIndex = 5
		'
		'更新
		'
		Me.更新.Location = New System.Drawing.Point(346, 124)
		Me.更新.Name = "更新"
		Me.更新.Size = New System.Drawing.Size(114, 21)
		Me.更新.TabIndex = 6
		Me.更新.Text = "更新"
		Me.更新.UseVisualStyleBackColor = True
		'
		'キャンセル
		'
		Me.キャンセル.CausesValidation = False
		Me.キャンセル.Location = New System.Drawing.Point(347, 163)
		Me.キャンセル.Name = "キャンセル"
		Me.キャンセル.Size = New System.Drawing.Size(114, 21)
		Me.キャンセル.TabIndex = 7
		Me.キャンセル.Text = "キャンセル"
		Me.キャンセル.UseVisualStyleBackColor = True
		'
		'ヘッド部
		'
		Me.ヘッド部.Controls.Add(Me.社員コード)
		Me.ヘッド部.Controls.Add(Me.Label2)
		Me.ヘッド部.Controls.Add(Me.Label1)
		Me.ヘッド部.Controls.Add(Me.確認)
		Me.ヘッド部.Controls.Add(Me.処理区分)
		Me.ヘッド部.Location = New System.Drawing.Point(55, 45)
		Me.ヘッド部.Name = "ヘッド部"
		Me.ヘッド部.Size = New System.Drawing.Size(479, 111)
		Me.ヘッド部.TabIndex = 0
		Me.ヘッド部.TabStop = False
		Me.ヘッド部.Text = "ヘッド部"
		'
		'社員コード
		'
		Me.社員コード.Location = New System.Drawing.Point(121, 66)
		Me.社員コード.Name = "社員コード"
		Me.社員コード.Size = New System.Drawing.Size(47, 19)
		Me.社員コード.TabIndex = 3
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Location = New System.Drawing.Point(21, 69)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(56, 12)
		Me.Label2.TabIndex = 2
		Me.Label2.Text = "社員コード"
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(21, 30)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(53, 12)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "処理区分"
		'
		'確認
		'
		Me.確認.Location = New System.Drawing.Point(346, 27)
		Me.確認.Name = "確認"
		Me.確認.Size = New System.Drawing.Size(114, 21)
		Me.確認.TabIndex = 4
		Me.確認.Text = "確認"
		Me.確認.UseVisualStyleBackColor = True
		'
		'処理区分
		'
		Me.処理区分.CausesValidation = False
		Me.処理区分.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.処理区分.FormattingEnabled = True
		Me.処理区分.Items.AddRange(New Object() {"修正", "新規", "削除"})
		Me.処理区分.Location = New System.Drawing.Point(120, 27)
		Me.処理区分.Name = "処理区分"
		Me.処理区分.Size = New System.Drawing.Size(127, 20)
		Me.処理区分.TabIndex = 1
		'
		'ステータス
		'
		Me.ステータス.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.通常ラベル})
		Me.ステータス.Location = New System.Drawing.Point(0, 465)
		Me.ステータス.Name = "ステータス"
		Me.ステータス.Size = New System.Drawing.Size(614, 22)
		Me.ステータス.TabIndex = 4
		Me.ステータス.Text = "StatusStrip1"
		'
		'通常ラベル
		'
		Me.通常ラベル.Name = "通常ラベル"
		Me.通常ラベル.Size = New System.Drawing.Size(0, 17)
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(614, 487)
		Me.Controls.Add(Me.ステータス)
		Me.Controls.Add(Me.ヘッド部)
		Me.Controls.Add(Me.ボディ部)
		Me.Controls.Add(Me.MenuStrip1)
		Me.KeyPreview = True
		Me.MainMenuStrip = Me.MenuStrip1
		Me.MaximizeBox = False
		Me.Name = "Form1"
		Me.Text = "Form1"
		Me.MenuStrip1.ResumeLayout(False)
		Me.MenuStrip1.PerformLayout()
		Me.ボディ部.ResumeLayout(False)
		Me.ボディ部.PerformLayout()
		Me.ヘッド部.ResumeLayout(False)
		Me.ヘッド部.PerformLayout()
		Me.ステータス.ResumeLayout(False)
		Me.ステータス.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents 終了 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ボディ部 As System.Windows.Forms.GroupBox
    Friend WithEvents ヘッド部 As System.Windows.Forms.GroupBox
    Friend WithEvents 処理区分 As System.Windows.Forms.ComboBox
    Friend WithEvents 確認 As System.Windows.Forms.Button
    Friend WithEvents キャンセル As System.Windows.Forms.Button
    Friend WithEvents 更新 As System.Windows.Forms.Button
    Friend WithEvents 生年月日 As System.Windows.Forms.DateTimePicker
    Friend WithEvents ステータス As System.Windows.Forms.StatusStrip
    Friend WithEvents 通常ラベル As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents 基本給 As Mtn.UserControl
    Friend WithEvents 社員名 As Mtn.UserControl
    Friend WithEvents 社員コード As Mtn.UserControl
    Friend WithEvents 処理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents メール送信 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents メール受信 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ブラウザ表示 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 印刷プレビュー As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ログ表示 As System.Windows.Forms.ToolStripMenuItem

End Class
