﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CMTN
{
    static class アプリケーションイベント
    {

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Startup();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

        }

        // ********************************************************
        // スタートアップ( シャットダウンイベント追加 )
        // ********************************************************
        static void Startup()
        {
            Application.ApplicationExit += new EventHandler(Shutdown);
        }

        // ********************************************************
        // シャットダウン
        // ********************************************************
        static void Shutdown(object sender, EventArgs e)
        {
            
//            Microsoft.VisualBasic.Interaction.MsgBox("終了", 0, "");
        }
    }
}