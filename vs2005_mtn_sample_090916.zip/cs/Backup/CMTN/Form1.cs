using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CMTN
{
    public partial class Form1 : Form
    {
        // ******************************************************
        // �R���X�g���N�^
        // ******************************************************
        public Form1()
        {
            InitializeComponent();
        }

        // ******************************************************
        // �t�H�[��������ꂽ���̏���
        // ******************************************************
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.db.Close();
        }

        private void �e�X�gToolStripMenuItem_Click(object sender, EventArgs e)
        {

            {
                Form2 Dialog = new Form2();
                DialogResult ret = Dialog.ShowDialog(this);
            } 
        }


    }
}