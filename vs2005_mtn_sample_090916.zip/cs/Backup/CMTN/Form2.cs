using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CMTN
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.lboxGrid1.ParentFit(this);
        }

        private void Form2_SizeChanged(object sender, EventArgs e)
        {
            this.lboxGrid1.ParentFit(this);
        }
    }
}