﻿namespace CMTN
{
    partial class Form2
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.lboxGrid1 = new CMTN.LIB.LboxGrid();
            ((System.ComponentModel.ISupportInitialize)(this.lboxGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // lboxGrid1
            // 
            this.lboxGrid1.AllowUserToAddRows = false;
            this.lboxGrid1.AllowUserToDeleteRows = false;
            this.lboxGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lboxGrid1.Location = new System.Drawing.Point(18, 40);
            this.lboxGrid1.Name = "lboxGrid1";
            this.lboxGrid1.ReadOnly = true;
            this.lboxGrid1.RowTemplate.Height = 21;
            this.lboxGrid1.Size = new System.Drawing.Size(621, 417);
            this.lboxGrid1.SizeBottom = 20;
            this.lboxGrid1.SizeLeft = 0;
            this.lboxGrid1.SizeRight = 0;
            this.lboxGrid1.SizeTop = 20;
            this.lboxGrid1.TabIndex = 0;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 525);
            this.Controls.Add(this.lboxGrid1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.SizeChanged += new System.EventHandler(this.Form2_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.lboxGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CMTN.LIB.LboxGrid lboxGrid1;
    }
}