﻿using System.IO;
using System.Text;
using System.Runtime.InteropServices;

namespace CMTN.LIB
{
public class INI 
{ 
    
    public string ini; 
    
    // ****************************************************** 
    // ini ファイル読み込み 
    // ****************************************************** 
    [DllImport("Kernel32.dll", CharSet = CharSet.Auto)] 
    private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName); 
    
    // ******************************************************** 
    // (コンストラクタの定義)( Sub で定義する ) 
    // ******************************************************** 
    public INI(string path) 
    { 
        
        ini = path; 
        
    } 
    
    // ****************************************************** 
    // 接続 DB の種類を取得 
    // ****************************************************** 
    public int GetDBType() 
    { 
        
        StringBuilder str = new StringBuilder(512); 
        
        GetPrivateProfileString("MTN", "ConnetctType", "1", str, 512, ini); 
        return int.Parse(str.ToString()); 
        
    } 
    
    // ****************************************************** 
    // 接続 Server を取得 
    // ****************************************************** 
    public string GetServer() 
    { 
        
        StringBuilder str = new StringBuilder(512); 
        int nType = GetDBType(); 
        
        switch (nType) { 
            case 1: 
                GetPrivateProfileString("MySQL", "Server", "localhost", str, 512, ini); 
                break; 
            case 2: 
                GetPrivateProfileString("Oracle", "Server", "localhost/ORCL", str, 512, ini); 
                break; 
            
        } 
        
        return str.ToString(); 
        
    } 
    
    // ****************************************************** 
    // 接続 Server を取得 
    // ****************************************************** 
    public string GetDB() 
    { 
        
        StringBuilder str = new StringBuilder(512); 
        int nType = GetDBType(); 
        
        switch (nType) { 
            case 1: 
                GetPrivateProfileString("MySQL", "Database", "", str, 512, ini); 
                break; 
            case 2: 
                str.Append(""); 
                break; 
            
        } 
        
        return str.ToString(); 
        
    } 
    
    // ****************************************************** 
    // 接続 Server を取得 
    // ****************************************************** 
    public string GetUser() 
    { 
        
        StringBuilder str = new StringBuilder(512); 
        int nType = GetDBType(); 
        
        switch (nType) { 
            case 1: 
                GetPrivateProfileString("MySQL", "User", "", str, 512, ini); 
                break; 
            case 2: 
                GetPrivateProfileString("Oracle", "User", "", str, 512, ini); 
                break; 
            
        } 
        
        return str.ToString(); 
        
    } 
    
    // ****************************************************** 
    // 接続 Server を取得 
    // ****************************************************** 
    public string GetPass() 
    { 
        
        StringBuilder str = new StringBuilder(512); 
        int nType = GetDBType(); 
        
        switch (nType) { 
            case 1: 
                GetPrivateProfileString("MySQL", "Password", "", str, 512, ini); 
                break; 
            case 2: 
                GetPrivateProfileString("Oracle", "Password", "", str, 512, ini); 
                break; 
            
        } 
        
        return str.ToString(); 
        
    } 
    
    // ****************************************************** 
    // 一般取得 
    // ****************************************************** 
    public string GetValue(string Section, string Entry) 
    { 
        
        StringBuilder str = new StringBuilder(512); 
        int nType = GetDBType(); 
        
        GetPrivateProfileString(Section, Entry, "", str, 512, ini); 
        
        return str.ToString(); 
        
    } 
    
    // ****************************************************** 
    // エラーメッセージの取得 
    // ****************************************************** 
    public string GetErrorMessage(string code) 
    { 
        
        StringBuilder str = new StringBuilder(512); 
        int nType = GetDBType(); 
        
        GetPrivateProfileString("Error", "E" + code, "", str, 512, ini); 
        
        return str.ToString(); 
        
    } 
    
    // ****************************************************** 
    // エラーメッセージの表示 
    // ****************************************************** 
    public void DispError(string code) 
    { 
        string str = this.GetErrorMessage(code); 
        Microsoft.VisualBasic.Interaction.MsgBox(str + "　　　", 0, "R205");
        
    }

    public void DispError(string code, ref System.Windows.Forms.TextBox target)
    {

        target.SelectAll();
        target.Focus();

        string str = this.GetErrorMessage(code);
        Microsoft.VisualBasic.Interaction.MsgBox(str + "　　　", 0, "R205");

    }
    public void DispError(string code, ref System.ComponentModel.CancelEventArgs e)
    {

        e.Cancel = true;

        string str = this.GetErrorMessage(code);
        Microsoft.VisualBasic.Interaction.MsgBox(str + "　　　", 0, "R205");

    }

    public void DispError(string code, 
        ref System.Windows.Forms.TextBox target, 
        ref System.ComponentModel.CancelEventArgs e)
    {

        target.SelectAll();
        target.Focus();

        e.Cancel = true;

        string str = this.GetErrorMessage(code);
        Microsoft.VisualBasic.Interaction.MsgBox(str + "　　　", 0, "R205");

    }
} 
}
