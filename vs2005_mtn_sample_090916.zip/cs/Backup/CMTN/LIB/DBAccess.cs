using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Odbc;

namespace CMTN.LIB
{
    public class DB
    {

        // �ڑ��I�u�W�F�N�g 
        public OdbcConnection myCon = new OdbcConnection();
        // �R�}���h�I�u�W�F�N�g 
        private OdbcCommand myCommand = new OdbcCommand();
        // �ڑ������� 
        public string strCon = string.Empty;

        // ******************************************************** 
        // (�R���X�g���N�^�̒�`)( Sub �Œ�`���� ) 
        // ******************************************************** 
        public DB(int type, string sv, string db, string user, string pass)
        {

            switch (type)
            {
                case 1:
                    strCon = string.Format("Driver={{MySQL ODBC 3.51 Driver}};" + "SERVER={0};" + "DATABASE={1};" + "UID={2};" + "PWD={3}", sv, db, user, pass);
                    break;
                case 2:
                    strCon = string.Format("Driver={{Microsoft ODBC for Oracle}};" + "SERVER={0};" + "UID={2};" + "PWD={3}", sv, db, user, pass);
                    break;
                default:
                    break;
            }

        }

        // ******************************************************** 
        // (�ڑ�����) 
        // ******************************************************** 
        public bool Connect()
        {
            bool functionReturnValue = false;

            functionReturnValue = true;

            // �ڑ�������Z�b�g 
            myCon.ConnectionString = strCon;

            // ==================================================== 
            // (��O����) 
            // ==================================================== 
            try
            {
                // �ڑ� 
                myCon.Open();
            }
            catch (Exception e)
            {
                functionReturnValue = false;
                Microsoft.VisualBasic.Interaction.MsgBox(e.Message,0,"�ڑ��G���[");
            }

            // �R�}���h�I�u�W�F�N�g��ڑ��Ɋ֌W�t���� 
            myCommand.Connection = myCon;
            return functionReturnValue;

        }

        // ******************************************************** 
        // ���s 
        // ******************************************************** 
        public int Execute(string str)
        {

            OdbcCommand myCommand = new OdbcCommand();
            myCommand.CommandText = str;
            myCommand.Connection = myCon;
            return myCommand.ExecuteNonQuery();

        }

        // ******************************************************** 
        // �ǂݍ��� ( �߂�l�� OdbcDataReader ) 
        // ******************************************************** 
        public OdbcDataReader Query(string str)
        {

            OdbcCommand myCommand = new OdbcCommand();
            myCommand.CommandText = str;
            myCommand.Connection = myCon;
            OdbcDataReader myReader = null;

            myReader = myCommand.ExecuteReader();
            myReader.Read();
            return myReader;

        }

        // ******************************************************** 
        // �񖼂�蕶����l�̎擾 
        // ******************************************************** 
        public string Value(ref OdbcDataReader myReader, string str)
        {

            int fld = 0;
            fld = myReader.GetOrdinal(str);
            String ret = "";
            try
            {
                ret = myReader.GetString(fld);
            }
            catch (Exception e)
            {
                Exception ie = e;
                ret = "";
            }

            return ret;

        }

        // ******************************************************** 
        // (�ڑ���������) 
        // ******************************************************** 
        public void Close()
        {

            myCon.Close();

        }

    }
}
