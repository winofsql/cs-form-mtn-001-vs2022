// ******************************************************
// �y�J���p�e�L�X�g�{�b�N�X�z
//
// �ړI�@�@�@ : �s�K�v�ȃv���p�e�B�̔r���ƕK�v�ȃ��\�b�h�ǉ�
// �쐬�ҁ@�@ : lightbox
// �t�@�C���� : LboxTextBox.cs
// ******************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace CMTN
{
    public partial class LboxTextBox : TextBox
    {
        public LboxTextBox()
        {
            InitializeComponent();

        }

        public static bool validateNone = false;

        protected override void OnValidating(System.ComponentModel.CancelEventArgs e)
        {

            // ****************************************************** 
            // validateNone �� True �Ȃ�΁AValdating �͔������Ȃ� 
            // ****************************************************** 
            if (!validateNone)
            {
                base.OnValidating(e);
            }

        }

        protected override void OnValidated(System.EventArgs e)
        {

            // ****************************************************** 
            // validateNone �� True �Ȃ�΁AValidated �͔������Ȃ� 
            // ****************************************************** 
            if (!validateNone)
            {
                base.OnValidated(e);
            }

        }
        private int _DataType = 0;


        // ****************************************************** 
        // �f�[�^�^( �v���p�e�B�����e�X�g ) 
        // ****************************************************** 
        [System.ComponentModel.Description("0:������\n1:����"), System.ComponentModel.DefaultValue(0)]
        public int DataType
        {
            get { return _DataType; }
            set { _DataType = value; }
        }


        // ****************************************************** 
        // �w�i�F
        // ****************************************************** 
        [System.ComponentModel.Browsable(false)]
        public override Color BackColor
        {
            get
            {
                return base.BackColor;
            }
            set
            {
                base.BackColor = value;
            }
        }

        // ****************************************************** 
        // �t�H���g
        // ****************************************************** 
        [System.ComponentModel.Browsable(false)]
        public override Font Font
        {
            get
            {
                return base.Font;
            }
            set
            {
                base.Font = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override bool AllowDrop
        {
            get
            {
                return base.AllowDrop;
            }
            set
            {
                base.AllowDrop = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override AnchorStyles Anchor
        {
            get
            {
                return base.Anchor;
            }
            set
            {
                base.Anchor = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override Point AutoScrollOffset
        {
            get
            {
                return base.AutoScrollOffset;
            }
            set
            {
                base.AutoScrollOffset = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override bool AutoSize
        {
            get
            {
                return base.AutoSize;
            }
            set
            {
                base.AutoSize = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override Image BackgroundImage
        {
            get
            {
                return base.BackgroundImage;
            }
            set
            {
                base.BackgroundImage = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override ImageLayout BackgroundImageLayout
        {
            get
            {
                return base.BackgroundImageLayout;
            }
            set
            {
                base.BackgroundImageLayout = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override BindingContext BindingContext
        {
            get
            {
                return base.BindingContext;
            }
            set
            {
                base.BindingContext = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        protected override bool CanRaiseEvents
        {
            get
            {
                return base.CanRaiseEvents;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override ContextMenu ContextMenu
        {
            get
            {
                return base.ContextMenu;
            }
            set
            {
                base.ContextMenu = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override ContextMenuStrip ContextMenuStrip
        {
            get
            {
                return base.ContextMenuStrip;
            }
            set
            {
                base.ContextMenuStrip = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        protected override CreateParams CreateParams
        {
            get
            {
                return base.CreateParams;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override Cursor Cursor
        {
            get
            {
                return base.Cursor;
            }
            set
            {
                base.Cursor = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        protected override bool DoubleBuffered
        {
            get
            {
                return base.DoubleBuffered;
            }
            set
            {
                base.DoubleBuffered = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override DockStyle Dock
        {
            get
            {
                return base.Dock;
            }
            set
            {
                base.Dock = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override Color ForeColor
        {
            get
            {
                return base.ForeColor;
            }
            set
            {
                base.ForeColor = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override Size MaximumSize
        {
            get
            {
                return base.MaximumSize;
            }
            set
            {
                base.MaximumSize = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override ISite Site
        {
            get
            {
                return base.Site;
            }
            set
            {
                base.Site = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override bool ShortcutsEnabled
        {
            get
            {
                return base.ShortcutsEnabled;
            }
            set
            {
                base.ShortcutsEnabled = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override int SelectionLength
        {
            get
            {
                return base.SelectionLength;
            }
            set
            {
                base.SelectionLength = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override string SelectedText
        {
            get
            {
                return base.SelectedText;
            }
            set
            {
                base.SelectedText = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override bool Multiline
        {
            get
            {
                return base.Multiline;
            }
            set
            {
                base.Multiline = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override int MaxLength
        {
            get
            {
                return base.MaxLength;
            }
            set
            {
                base.MaxLength = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override RightToLeft RightToLeft
        {
            get
            {
                return base.RightToLeft;
            }
            set
            {
                base.RightToLeft = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public override Size MinimumSize
        {
            get
            {
                return base.MinimumSize;
            }
            set
            {
                base.MinimumSize = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new AutoCompleteMode AutoCompleteMode
        {
            get
            {
                return base.AutoCompleteMode;
            }
            set
            {
                base.AutoCompleteMode = value;
            }
        }
 
        [System.ComponentModel.Browsable(false)]
        public new AutoCompleteSource AutoCompleteSource
        {
            get
            {
                return base.AutoCompleteSource;
            }
            set
            {
                base.AutoCompleteSource = value;
            }
        }
 
        [System.ComponentModel.Browsable(false)]
        public new AutoCompleteStringCollection AutoCompleteCustomSource 
        {
            get
            {
                return base.AutoCompleteCustomSource;
            }
            set
            {
                base.AutoCompleteCustomSource = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new Boolean TabStop
        {
            get
            {
                return base.TabStop;
            }
            set
            {
                base.TabStop = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new Padding Margin
        {
            get
            {
                return base.Margin;
            }
            set
            {
                base.Margin = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new Boolean UseSystemPasswordChar
        {
            get
            {
                return base.UseSystemPasswordChar;
            }
            set
            {
                base.UseSystemPasswordChar = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new Boolean WordWrap
        {
            get
            {
                return base.WordWrap;
            }
            set
            {
                base.WordWrap = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new Boolean UseWaitCursor
        {
            get
            {
                return base.UseWaitCursor;
            }
            set
            {
                base.UseWaitCursor = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new ScrollBars ScrollBars 
        {
            get
            {
                return base.ScrollBars;
            }
            set
            {
                base.ScrollBars = value;
            }
        }
        
        [System.ComponentModel.Browsable(false)]
        public new string[] Lines 
        {
            get
            {
                return base.Lines;
            }
            set
            {
                base.Lines = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new Boolean HideSelection
        {
            get
            {
                return base.HideSelection;
            }
            set
            {
                base.HideSelection = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new CharacterCasing CharacterCasing 
        {
            get
            {
                return base.CharacterCasing;
            }
            set
            {
                base.CharacterCasing = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new ControlBindingsCollection DataBindings
        {
            get
            {
                return base.DataBindings;
            }
        }


        // ****************************************************** 
        // �O���r��( overridable �ł͖����v���p�e�B )
        // ****************************************************** 
        [System.ComponentModel.Browsable(false)]
        public new BorderStyle BorderStyle
        {
            get
            {
                return base.BorderStyle;
            }
            set
            {
                base.BorderStyle = value;
            }
        }

        // ****************************************************** 
        // ���[�U�[�⏕
        // ****************************************************** 
        [System.ComponentModel.Browsable(false)]
        public new String AccessibleDescription 
        {
            get
            {
                return base.AccessibleDescription;
            }
            set
            {
                base.AccessibleDescription = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new String AccessibleName
        {
            get
            {
                return base.AccessibleName;
            }
            set
            {
                base.AccessibleName = value;
            }
        }

        [System.ComponentModel.Browsable(false)]
        public new AccessibleRole AccessibleRole
        {
            get
            {
                return base.AccessibleRole;
            }
            set
            {
                base.AccessibleRole = value;
            }
        }
     }
}
