using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace CMTN.LIB
{
    public partial class LboxGrid : DataGridView
    {
        public LboxGrid()
        {
            InitializeComponent();
        }

        public int nCurrentRow = -1;

        // ****************************************************** 
        // �J�����ǉ� 
        // ****************************************************** 
        public void AddColumn(string strName, string strTitle)
        {

            this.Columns.Add(strName, strTitle);

        }

        // ****************************************************** 
        // �J�������ǉ� 
        // ****************************************************** 
        public void SetColumnWidth(string strName, int nWidth)
        {
            this.Columns[strName].Width = nWidth;

        }

        // ****************************************************** 
        // �s�ǉ� 
        // ****************************************************** 
        public void AddRow()
        {

            nCurrentRow = this.Rows.Add(1);

        }

        // ****************************************************** 
        // �J�����f�[�^�ύX 
        // ****************************************************** 
        public void SetColumnText(int nIndex, string strName, string strText)
        {

            this.Rows[nIndex].Cells[strName].Value = strText;

        }

        // ****************************************************** 
        // �J�����f�[�^�ύX 
        // ****************************************************** 
        public void SetColumnText(string strName, string strText)
        {

            this.Rows[nCurrentRow].Cells[strName].Value = strText;

        }

        // ****************************************************** 
        // �J������\���E��\�� 
        // ****************************************************** 
        public void SetColumnVisible(string strName, bool bFlg)
        {

            this.Columns[strName].Visible = bFlg;

        }

        // ****************************************************** 
        // �s�����ׂč폜 
        // ****************************************************** 
        public void Clear()
        {

            int count = this.Rows.Count;
            int i;

            for (i = count - 1; i >= 0; i += -1)
            {
                this.Rows.RemoveAt(i);
            }

        }

        // ****************************************************** 
        // ������ 
        // ****************************************************** 
        public void Reset()
        {

            this.Columns.Clear();

        }

        // ****************************************************** 
        // �T�C�Y�������\�b�h 
        // ****************************************************** 
        public void ParentFit(System.Windows.Forms.Form TargetForm)
        {

            this.Left = _SizeLeft;
            this.Top = _SizeTop;
            this.Width = TargetForm.ClientRectangle.Width - _SizeLeft - _SizeRight;
            this.Height = TargetForm.ClientRectangle.Height - _SizeTop - _SizeBottom;

        }


        private int _SizeLeft = 0;
        private int _SizeTop = 0;
        private int _SizeRight = 0;
        private int _SizeBottom = 0;
        // ****************************************************** 
        // �T�C�Y�����p�ʒu�v���p�e�B 
        // ****************************************************** 
        public int SizeLeft
        {
            get { return _SizeLeft; }
            set { _SizeLeft = value; }
        }
        public int SizeRight
        {
            get { return _SizeRight; }
            set { _SizeRight = value; }
        }
        public int SizeTop
        {
            get { return _SizeTop; }
            set { _SizeTop = value; }
        }
        public int SizeBottom
        {
            get { return _SizeBottom; }
            set { _SizeBottom = value; }
        }

    } 

}

