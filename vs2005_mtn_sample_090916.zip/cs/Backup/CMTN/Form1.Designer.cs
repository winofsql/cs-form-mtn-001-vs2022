﻿namespace CMTN
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.ヘッド部 = new System.Windows.Forms.GroupBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.確認 = new System.Windows.Forms.Button();
            this.処理区分 = new System.Windows.Forms.ComboBox();
            this.ボディ部 = new System.Windows.Forms.GroupBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.生年月日 = new System.Windows.Forms.DateTimePicker();
            this.更新 = new System.Windows.Forms.Button();
            this.キャンセル = new System.Windows.Forms.Button();
            this.社員コード = new CMTN.LboxTextBox();
            this.基本給 = new CMTN.LboxTextBox();
            this.社員名 = new CMTN.LboxTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.テストToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ヘッド部.SuspendLayout();
            this.ボディ部.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ヘッド部
            // 
            this.ヘッド部.Controls.Add(this.社員コード);
            this.ヘッド部.Controls.Add(this.Label2);
            this.ヘッド部.Controls.Add(this.Label1);
            this.ヘッド部.Controls.Add(this.確認);
            this.ヘッド部.Controls.Add(this.処理区分);
            this.ヘッド部.Location = new System.Drawing.Point(55, 45);
            this.ヘッド部.Name = "ヘッド部";
            this.ヘッド部.Size = new System.Drawing.Size(479, 111);
            this.ヘッド部.TabIndex = 2;
            this.ヘッド部.TabStop = false;
            this.ヘッド部.Text = "ヘッド部";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(21, 69);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(56, 12);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "社員コード";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(21, 30);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(53, 12);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "処理区分";
            // 
            // 確認
            // 
            this.確認.Location = new System.Drawing.Point(346, 27);
            this.確認.Name = "確認";
            this.確認.Size = new System.Drawing.Size(114, 21);
            this.確認.TabIndex = 4;
            this.確認.Text = "確認";
            this.確認.UseVisualStyleBackColor = true;
            // 
            // 処理区分
            // 
            this.処理区分.CausesValidation = false;
            this.処理区分.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.処理区分.FormattingEnabled = true;
            this.処理区分.Items.AddRange(new object[] {
            "修正",
            "新規",
            "削除"});
            this.処理区分.Location = new System.Drawing.Point(120, 27);
            this.処理区分.Name = "処理区分";
            this.処理区分.Size = new System.Drawing.Size(127, 20);
            this.処理区分.TabIndex = 1;
            // 
            // ボディ部
            // 
            this.ボディ部.Controls.Add(this.基本給);
            this.ボディ部.Controls.Add(this.社員名);
            this.ボディ部.Controls.Add(this.Label5);
            this.ボディ部.Controls.Add(this.Label4);
            this.ボディ部.Controls.Add(this.Label3);
            this.ボディ部.Controls.Add(this.生年月日);
            this.ボディ部.Controls.Add(this.更新);
            this.ボディ部.Controls.Add(this.キャンセル);
            this.ボディ部.Enabled = false;
            this.ボディ部.Location = new System.Drawing.Point(55, 174);
            this.ボディ部.Name = "ボディ部";
            this.ボディ部.Size = new System.Drawing.Size(479, 193);
            this.ボディ部.TabIndex = 3;
            this.ボディ部.TabStop = false;
            this.ボディ部.Text = "ボディ部";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(21, 123);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(53, 12);
            this.Label5.TabIndex = 4;
            this.Label5.Text = "生年月日";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(21, 81);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(29, 12);
            this.Label4.TabIndex = 2;
            this.Label4.Text = "給与";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(21, 42);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(29, 12);
            this.Label3.TabIndex = 0;
            this.Label3.Text = "氏名";
            // 
            // 生年月日
            // 
            this.生年月日.Location = new System.Drawing.Point(121, 120);
            this.生年月日.Name = "生年月日";
            this.生年月日.ShowCheckBox = true;
            this.生年月日.Size = new System.Drawing.Size(183, 19);
            this.生年月日.TabIndex = 5;
            // 
            // 更新
            // 
            this.更新.Location = new System.Drawing.Point(346, 100);
            this.更新.Name = "更新";
            this.更新.Size = new System.Drawing.Size(114, 21);
            this.更新.TabIndex = 6;
            this.更新.Text = "更新";
            this.更新.UseVisualStyleBackColor = true;
            // 
            // キャンセル
            // 
            this.キャンセル.CausesValidation = false;
            this.キャンセル.Location = new System.Drawing.Point(347, 139);
            this.キャンセル.Name = "キャンセル";
            this.キャンセル.Size = new System.Drawing.Size(114, 21);
            this.キャンセル.TabIndex = 7;
            this.キャンセル.Text = "キャンセル";
            this.キャンセル.UseVisualStyleBackColor = true;
            // 
            // 社員コード
            // 
            this.社員コード.Location = new System.Drawing.Point(120, 66);
            this.社員コード.Name = "社員コード";
            this.社員コード.Size = new System.Drawing.Size(122, 19);
            this.社員コード.TabIndex = 5;
            // 
            // 基本給
            // 
            this.基本給.Location = new System.Drawing.Point(121, 78);
            this.基本給.Name = "基本給";
            this.基本給.Size = new System.Drawing.Size(122, 19);
            this.基本給.TabIndex = 9;
            // 
            // 社員名
            // 
            this.社員名.Location = new System.Drawing.Point(121, 39);
            this.社員名.Name = "社員名";
            this.社員名.Size = new System.Drawing.Size(212, 19);
            this.社員名.TabIndex = 8;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.テストToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(614, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // テストToolStripMenuItem
            // 
            this.テストToolStripMenuItem.Name = "テストToolStripMenuItem";
            this.テストToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.テストToolStripMenuItem.Text = "テスト";
            this.テストToolStripMenuItem.Click += new System.EventHandler(this.テストToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 445);
            this.Controls.Add(this.ヘッド部);
            this.Controls.Add(this.ボディ部);
            this.Controls.Add(this.menuStrip1);
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ヘッド部.ResumeLayout(false);
            this.ヘッド部.PerformLayout();
            this.ボディ部.ResumeLayout(false);
            this.ボディ部.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.GroupBox ヘッド部;
        private LboxTextBox 社員コード;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button 確認;
        internal System.Windows.Forms.ComboBox 処理区分;
        internal System.Windows.Forms.GroupBox ボディ部;
        private LboxTextBox 社員名;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.DateTimePicker 生年月日;
        internal System.Windows.Forms.Button 更新;
        internal System.Windows.Forms.Button キャンセル;
        private LboxTextBox 基本給;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem テストToolStripMenuItem;


    }
}

