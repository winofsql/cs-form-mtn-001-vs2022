using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CMTN.LIB;

namespace CMTN
{
    public partial class Form1 : Form
    {

        public string PGDIR = Application.StartupPath;
        public const string INI_NAME = "db.ini";
        public string INI_PATH = "";
        public INI ini;
        public DB db;

        // ******************************************************
        // �t�H�[���\���O�̏�������
        // ******************************************************
        private void Form1_Load(object sender, EventArgs e)
        {
            INI_PATH = PGDIR + @"\" + INI_NAME;
            // INI �t�@�C�������I�u�W�F�N�g�̃C���X�^���X���쐬 
            ini = new INI(INI_PATH);

            // DB �ڑ� 
            db = new DB(
                ini.GetDBType(),
                ini.GetServer(), 
                ini.GetDB(), 
                ini.GetUser(), 
                ini.GetPass()
            );
            db.Connect();

        }

        // ******************************************************
        // �t�H�[���\����̏�������
        // ******************************************************
        private void Form1_Shown(object sender, EventArgs e)
        {
            this.�Ј��R�[�h.Focus();
        }
    }
}